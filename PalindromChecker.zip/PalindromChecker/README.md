# se2_schmid
